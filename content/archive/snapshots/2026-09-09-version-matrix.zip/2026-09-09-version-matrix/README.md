# Version Matrix — 2026-09-09

A second, follow-on archive to `2026-09-09-content-style-and-version-artifacts.zip`
(already merged in this repo at `content/archive/snapshots/`). That archive
held the individual real snapshots; this one holds the map that ties them
together plus the specific cross-fit combinations built from them.

## Contents

### `matrix/version-matrix.html`
The map: a 5×7 grid of content versions (C1–C5) × visual themes (T1–T7).
Every filled cell links to a real page — either how it actually shipped
(native) or a real cross-fit built for comparison. See the page itself for
the full legend and the C/T version key.

### `cross-fit-cells/` — real content, refit into a theme it never shipped in
- `c1-in-t4.html` — C1 (long-form Module 1, real unedited text) in T4 (TestV3 theme)
- `c1-in-t5.html` — C1 (long-form Module 1, real unedited text) in T5 (V4 theme)
- `c3-in-t5.html` — C3 (hybrid course Lesson 1.2, real unedited text) in T5 (V4 theme)

Each is an excerpt, not the full source document — the full C1 and C3
documents are in the prior archive. Only page chrome and CSS class wiring
were constructed; lesson prose is unedited.

### `theme-references/` — real standalone theme concepts (T6, T7)
Complete, self-contained concept pages that were built and never adopted
site-wide. No processing needed — these ship as their own real HTML/CSS/JS,
only Google Fonts as an external dependency.

## Provenance

| File | Source ref | Source path | Blob SHA | Fidelity |
|---|---|---|---|---|
| `c1-in-t4.html` | text: `archive/v1-multipage-2026-09-03`; theme: `main` + `main` | `courses/_archived/module-1-welcome-to-the-live-event-world.html` (excerpt) + `css/theme.css` + `css/testv3.css` | text: `f9f4660b74d8c6d06f90b0deab38158de75c178b`; testv3.css: `f46e66b97313e484c3ea642d2cc001825126576f` | text unaltered (excerpted); built this session |
| `c1-in-t5.html` | text: `archive/v1-multipage-2026-09-03`; theme: `main` | same module-1 text + `css/blueprint-v4.css` | text: `f9f4660b74d8c6d06f90b0deab38158de75c178b` | text unaltered (excerpted); built this session |
| `c3-in-t5.html` | text: `archive/frozen-v2-exact-2026-09-07` (identical blob on v1); theme: `main` | `courses/stagehand-fundamentals.html`, Lesson 1.2 (excerpt) + `css/blueprint-v4.css` | text: `7f988e07f6238d761a9e9f0d68e929f56b379a11` | text unaltered (excerpted, one quiz interaction dropped); built this session |
| `t6-fresh-blueprint.html` | `claude/fresh-blueprint-concept-11l4vg` | `design-concepts/2026-08-31-blueprint-fresh-concept.html` | `1d925eb00840def2051f87ccf90c5e8877f9a55e` | unaltered |
| `t7-fresh-industrial.html` | `claude/fresh-industrial-concept-11l4vg` | `design-concepts/2026-08-31-industrial-fresh-concept.html` | `71f8949e35fe5bc68663f10a3c5ea9652a010309` | unaltered |
| `version-matrix.html` | — | links only, no embedded copies of the above | — | built this session |

**Theme T2 note (road-case variant):** cited in `version-matrix.html`'s key
but not built as its own cross-fit page — its `theme.css`
(`b8a668280fa078f98328f82c6d01824103e31fd9`) diffs only 158 lines against
T1's (`0ee8992f7a44a78fc66b87063257f683de6c289d`), so a cross-fit would look
nearly identical to what's already in the T1 column. `course-shell.css` is
`bd88832485ba0518aaae9892ae95b902bf4c06a0`, both on
`ui/unified-course-shell-road-case`.

## Registration note

Same as the prior archive: this is a targeted reference archive, not a
formal entry in `content/archive/diff-manifest.json` — that registry has a
narrower, different scope (the pre-vNext/vNext course-version-candidate
decision). This README is this archive's own provenance record.

## Status

Reference archive from an exploratory session. Not linked from the live
site, not part of any current build, not owner-reviewed for publication.
