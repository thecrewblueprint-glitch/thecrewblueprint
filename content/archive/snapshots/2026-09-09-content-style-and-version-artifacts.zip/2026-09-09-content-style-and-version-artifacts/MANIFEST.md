# Provenance Manifest — 2026-09-09 Content Style & Version Artifacts

One row per file in this archive: source branch/ref, source path, source
git blob SHA (`git cat-file -t <sha>` resolves it in this repo), and
fidelity. Verify any entry with:

```
git show <ref>:<path>          # view the source blob
git ls-tree <ref> -- <path>    # confirm its blob SHA
```

## Fidelity key

- **unaltered** — byte-identical body text/markup to the source blob; only
  mechanical packaging changes (inlining an external CSS/JS/image
  dependency, dropping an unreachable external script) were made outside
  the content itself.
- **enriched, source-based** — started from the cited source blob but was
  further developed inside the published artifact after initial packaging
  (see note). Not a literal blob match; flagged here rather than silently
  presented as identical.
- **built this session** — not derived from a single source blob; states
  its inputs.

## v4-site/ — ref: `main`

| File | Source path | Blob SHA | Fidelity |
|---|---|---|---|
| 01-home.html | `index.html` | `02916d75fd7fa43aaaed6742eac6c2eb383da4fa` | unaltered |
| 02-start-here.html | `start.html` | `ef3b4bda38d50425609a958506df705c9946e9e5` | unaltered |
| 03-courses.html | `learn.html` | `9da280ced98ca6a27c2cc67d5f3fe9a640c9528d` | unaltered |
| 04-advanced.html | `advanced.html` | `b5267b243eb4ff9e02522eb02ca0c86a1adc3211` | unaltered |
| 05-sources.html | `sources-v4.html` | `fa3f5db5d762108513716adba3060b3e66a346c2` | unaltered |
| 06-crew-ready.html | `courses-v4/crew-ready.html` | `a343aff1502d8d79c02d4cb6c48c971d9cf26418` | unaltered |
| 07-department-explorer.html | `courses-v4/department-explorer.html` | `9f784b38980e55097daedbad0de2258a632c189d` | unaltered |
| 08-shop-logistics.html | `courses-v4/shop-logistics.html` | `91ec880ff5ee504fca5104d064f0ad660fd95a81` | unaltered |
| 09-systems-thinking.html | `courses-v4/systems-thinking.html` | `7acdc8f8dc7f0c8a70a95a64a9a25be37bb7a202` | unaltered |

Shared deps inlined into every file above: `css/blueprint-v4.css`,
`js/blueprint-v4.js` (both `main`); `01-home.html` additionally inlines
`css/homepage-review.css` (`main`). The Clerk auth widget (`<script>` tags
loading an external CDN) was removed from every page — it cannot reach its
CDN from inside a published artifact and carries no course content.

## long-form-modules/ — ref: `archive/v1-multipage-2026-09-03`

| File | Source path | Blob SHA | Fidelity |
|---|---|---|---|
| 00-course-hub.html | `courses/_archived/stagehand-fundamentals-original.html` | `8bd230db48102579db36f5a04e2a152653bcbae2` | unaltered |
| module-1.html | `courses/_archived/module-1-welcome-to-the-live-event-world.html` | `f9f4660b74d8c6d06f90b0deab38158de75c178b` | unaltered |
| module-2.html | `courses/_archived/module-2-safety-mindset-before-skillset.html` | `d0e3a5ef845f46d2a1001fedc53c2240050aa111` | unaltered |
| module-3.html | `courses/_archived/module-3-ppe-clothing-and-what-to-bring.html` | `ef83d64210f958458492b68df009a60cc42f02a9` | unaltered |
| module-4.html | `courses/_archived/module-4-venue-and-jobsite-awareness.html` | `70bde9bfe0370a507c3929f5f1d9bf21018a4889` | unaltered |
| module-5.html | `courses/_archived/module-5-load-in-fundamentals.html` | `42d5dd43da56f09376607f78f2289db725bd07e8` | unaltered |
| module-6.html | `courses/_archived/module-6-stagehand-communication-and-crew-etiquette.html` | `a8b8e871e11357b0b6230db9c544ff62b48c07e8` | unaltered |
| module-7.html | `courses/_archived/module-7-department-basics.html` | `c8dfa0337be72c2a89cd4d5318ba8a992851e54d` | unaltered |
| module-8.html | `courses/_archived/module-8-tools-gear-and-handling-basics.html` | `7ca1a57a0fbd2e84992eb0a6d3057a5a1bb732c7` | unaltered |
| module-9.html | `courses/_archived/module-9-load-out-fundamentals.html` | `e2ad36538b7569d1248a652dfbb2addf02a7b6ff` | unaltered |
| module-10.html | `courses/_archived/module-10-getting-hired-getting-called-back-and-growing.html` | `219de2d68bd5eef84b01da306e0ae91bc1c8f722` | unaltered |

Shared deps inlined into all 11 files: `css/theme.css`, `js/main.js`
(both `archive/v1-multipage-2026-09-03`). Diagram `<iframe>` embeds inside
modules 4/5/8 point at externally hosted artifact URLs from earlier work
and are left as-is (out of scope for this archive; may not render inside
another viewer's frame due to cross-origin restrictions).

## tiered-course-pair/ — ref: `archive/v1-multipage-2026-09-03`

| File | Source path | Blob SHA | Fidelity |
|---|---|---|---|
| course-1-support.html | `courses/pathway-lighting-01-support.html` | `0ed1cc9e4e6c3786b35cebb6ae6d2da9603747e5` | **enriched, source-based** |
| course-2-production-flow.html | `courses/pathway-lighting-02-production-flow.html` | `4537016731a9c7174a5adee273c55d8d6ec3c83e` | unaltered |

**Note on course-1-support.html:** the version in this archive was
developed further inside the published Claude artifact after the initial
unaltered snapshot was posted — a richer, fully interactive rebuild
(JSON-driven lesson/quiz engine, expanded lesson content, real source
citations) replaced the plain static snapshot at that same URL before this
file was captured for the archive. It is not a byte match for the cited
blob; the blob is its starting point, not its literal content. Both files
share inlined `css/tiered-course.css` and `css/course-consent.css`
(`archive/v1-multipage-2026-09-03`) plus `js/tiered-course.js` and a
path-bootstrapping-patched copy of `js/course-consent.js` (same ref) —
`document.currentScript.src` is empty for an inlined `<script>`, so the
consent script's site-root resolution was changed to fall back to
`window.location.href` instead of throwing.

## v5-prototype/

| File | Inputs | Fidelity |
|---|---|---|
| crew-ready-v5-prototype.html | Lesson text verbatim from `courses-v4/crew-ready.html` (`main`, blob `a343aff1502d8d79c02d4cb6c48c971d9cf26418`) + CSS tokens/chrome from `css/theme.css` (`archive/v1-multipage-2026-09-03`) | built this session |

## other-real-snapshots/

| File | Source ref | Source path(s) | Blob SHA(s) | Fidelity |
|---|---|---|---|---|
| stagehand-fundamentals-hybrid-retention-course.html | `archive/frozen-v2-exact-2026-09-07` (identical blob on `archive/v1-multipage-2026-09-03`) | `courses/stagehand-fundamentals.html` | `7f988e07f6238d761a9e9f0d68e929f56b379a11` | unaltered |
| v1-homepage.html | `archive/v1-multipage-2026-09-03` | `index.html` | `06991c19d84eee73f2026d527991e4a8ffe2a03e` | unaltered |
| v2-full-site.html | `archive/frozen-v2-exact-2026-09-07` @ commit `1b1ddb0649d5a66bfff91b74791b4f3ce4f4c256` | `_includes/v2-baseline.html` + 5 Jekyll-injected overlays (`css/v2-client-layer.css`, `css/v2-usability.css`, `css/v2-footer-three-column.css`, `css/v2-layout-fixes.css`, `css/current-centering.css` and their paired `.js` files) | baseline: `57460d5fd788fe5f4db9d744867445c1ae9b9967` | unaltered — assembled exactly as the repo's own Jekyll front matter (`index.html`) specifies |
| clean-sheet-lab.html | `archive/frozen-vnext-clean-sheet-exact-2026-09-07` | `lab/clean-sheet-v1/index.html` + `app.js` + `content.js` + `context-labs.js` + `styles.css` | index: `9d8e09b3b62e0b6b59c1f48abd06abe88eaf81c4` | unaltered |

## Registration note

This is a targeted reference archive, not a formal entry in
`content/archive/diff-manifest.json` (that registry tracks the
pre-vNext/vNext course-version-candidate decision, a different, narrower
scope). This manifest is this archive's own provenance record.
