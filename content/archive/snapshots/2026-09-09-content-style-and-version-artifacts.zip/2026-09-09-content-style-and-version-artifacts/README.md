# Content Style & Version Artifacts — 2026-09-09

Captured during a Claude session comparing site versions and course content
styles. Each HTML file is self-contained (CSS/JS inlined, images as base64)
and opens directly in a browser — no server or build step needed.

All files are also published live at claude.ai/code/artifact/... URLs (linked
below); those links are what the internal navigation inside these files
points to, so browsing the local copies still crosses out to the live pages
for anything not included in this archive.

## Provenance

`MANIFEST.md` in this same directory lists, per file: source branch/ref,
source path, source git blob SHA, and fidelity (unaltered / enriched /
built this session). This README describes the archive; MANIFEST.md is
the auditable record.

## What's real vs. built

Every file carries a banner at the top of the page stating what it is.
Two kinds:

- **"REAL FILE, UNALTERED CONTENT"** — pulled directly from a git blob in
  this repo's history. The only edits made were mechanical: inlining an
  external CSS/JS/image dependency so the file works standalone, or
  dropping an unreachable external script (the Clerk auth widget, which
  calls out to a live CDN). Lesson text, structure, and logic are untouched.
- **"V5 PROTOTYPE, BUILT THIS SESSION"** — the one file that is not a
  pre-existing source file. It combines real V4 lesson text (unedited) with
  real V2 CSS chrome, as a working demonstration, not a shipped page.

## Contents

### `v4-site/` — the current live V4 build, complete and cross-linked
9 real pages from `main`, cross-linked to each other (and to the live
artifact URLs) so the nav actually works: `01-home.html` · `02-start-here.html`
· `03-courses.html` · `04-advanced.html` · `05-sources.html` ·
`06-crew-ready.html` · `07-department-explorer.html` ·
`08-shop-logistics.html` · `09-systems-thinking.html`.

### `long-form-modules/` — the original 10-module course, pre-condensation
`00-course-hub.html` plus `module-1.html` through `module-10.html`, from
`archive/v1-multipage-2026-09-03` (`courses/_archived/module-*.html`). This
is what Stagehand Fundamentals looked like before it was rewritten into the
34-lesson hybrid course.

### `tiered-course-pair/` — the Course 1 / Course 2 tiered department system
`course-1-support.html` (entry-level, assigned work) and
`course-2-production-flow.html` (systems depth, troubleshooting), both
sourced from real Lighting-department pages on
`archive/v1-multipage-2026-09-03`. `course-1-support.html` was further
developed inside its published artifact after the initial snapshot (an
interactive lesson/quiz rebuild) — see `MANIFEST.md` for exactly what
changed; `course-2-production-flow.html` is unaltered.

### `v5-prototype/`
`crew-ready-v5-prototype.html` — real V4 Crew Ready lesson text restyled
with real V2 theme.css tokens and nav/footer chrome.

### `other-real-snapshots/`
- `stagehand-fundamentals-hybrid-retention-course.html` — the current
  34-lesson hybrid course (identical file on v1 and v2; this is the
  "retention-focused" build per `companies/crew-blueprint/12_learning_landscape_registry.md`
  — hybrid and retention-focused are the same course, not two).
- `v2-full-site.html` — the complete V2 hash-routed SPA, assembled exactly
  as GitHub Pages builds it (`_includes/v2-baseline.html` + its 5 Jekyll-
  injected overlay files). All 143 courses reachable via the in-page nav.
- `v1-homepage.html` — the original multipage V1 build.
- `clean-sheet-lab.html` — the situation-first prototype from
  `archive/frozen-vnext-clean-sheet-exact-2026-09-07`.

## Live links (same content, hosted)

v4-site: https://claude.ai/code/artifact/64bade7b-115c-4e51-a4de-de475660b26a (home) ·
https://claude.ai/code/artifact/f9dd74c2-db94-40ed-ab4d-e38ba07e3213 (start) ·
https://claude.ai/code/artifact/f682f34b-08e3-4523-9210-65a1b7758fdc (courses) ·
https://claude.ai/code/artifact/31037fe1-561b-4574-abf2-c8e336f1f552 (advanced) ·
https://claude.ai/code/artifact/d676726b-fd8b-4fa2-b0e0-ba20397782d5 (sources) ·
https://claude.ai/code/artifact/fafb1efd-671f-4143-90e4-db503a11c44a (crew ready) ·
https://claude.ai/code/artifact/66a28af3-9506-453c-9203-18d7b689abf9 (department explorer) ·
https://claude.ai/code/artifact/fadd77ce-750c-4bbd-a136-3482ba63bfe4 (shop & logistics) ·
https://claude.ai/code/artifact/d209d9bf-877e-4474-af59-c16bf794441b (systems thinking)

long-form-modules: https://claude.ai/code/artifact/7c607f35-a21f-4a79-936f-61422df9be82 (hub) ·
https://claude.ai/code/artifact/fb229270-dab9-44e2-ab51-3d6a8e0f6e48 (mod 1) ·
https://claude.ai/code/artifact/c0612673-8969-40ca-8022-24b9dd1340ee (mod 2) ·
https://claude.ai/code/artifact/833adca2-38b4-4bb9-a963-e465c6b8e80c (mod 3) ·
https://claude.ai/code/artifact/9ffe9a88-fab5-41dd-8449-261d1961353e (mod 4) ·
https://claude.ai/code/artifact/d2103d92-dbd0-4b53-9a79-1731ef1bc956 (mod 5) ·
https://claude.ai/code/artifact/b0ba0125-7cfc-4df0-a0a5-a3c808b320cf (mod 6) ·
https://claude.ai/code/artifact/04652e81-8df4-4bb9-9b1d-7ecf5c893266 (mod 7) ·
https://claude.ai/code/artifact/7f743026-456f-4a38-8d9d-9106ffaa6d9c (mod 8) ·
https://claude.ai/code/artifact/79528b37-0045-41de-8977-149fb45eec6b (mod 9) ·
https://claude.ai/code/artifact/90f9bf49-cc0e-41ff-9799-ba800e471afb (mod 10)

tiered-course-pair: https://claude.ai/code/artifact/7933e4fa-19e5-4e93-b08a-e6a9a40e8717 (course 1) ·
https://claude.ai/code/artifact/f403c648-9dc6-4dd5-a6bb-4b35033740d4 (course 2)

v5-prototype: https://claude.ai/code/artifact/95b96d20-052f-48f6-8018-151a66eb6f62

other-real-snapshots: https://claude.ai/code/artifact/4b49da2e-63e1-49ba-bb5b-4cf6effcd533 (hybrid/retention course) ·
https://claude.ai/code/artifact/2e858f0e-8b80-475e-bd31-8d477b61a26f (v2 full site) ·
https://claude.ai/code/artifact/72d6cba0-90c3-4303-8a55-a31b4b5f6e1f (v1 homepage) ·
https://claude.ai/code/artifact/677af132-07fd-46f0-9711-3b59976f9baf (clean-sheet lab)

## Status

Reference archive from an exploratory session. Not linked from the live
site, not part of any current build, not owner-reviewed for publication.
Nothing here supersedes or edits the live `main` build.
